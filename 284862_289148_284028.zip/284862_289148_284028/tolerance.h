#ifndef TOLERANCES_H
#define TOLERANCES_H

#define EPSIL_ZERO				1e-2
#define EPSIL_ALIGNEMENT		0.0625

#endif
