#ifndef DRAW_H
#define DRAW_H

void draw_part(double xc, double yc,double rayon);
void draw_robot(double xc, double yc, double angle);

#endif
